package zachkingcade.dev.user.application;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import zachkingcade.dev.user.adapter.persistence.jpa.UserEntity;
import zachkingcade.dev.user.application.commands.CreateSessionCommand;
import zachkingcade.dev.user.application.commands.LoginUserCommand;
import zachkingcade.dev.user.application.commands.RegisterUserCommand;
import zachkingcade.dev.user.application.exception.ApplicationException;
import zachkingcade.dev.user.application.exception.NotFoundException;
import zachkingcade.dev.user.application.port.in.Session.CreateUserSessionUseCase;
import zachkingcade.dev.user.application.port.in.user.LoginUserUseCase;
import zachkingcade.dev.user.application.port.in.user.RegisterUserUseCase;
import zachkingcade.dev.user.application.port.out.user.UserRepositoryPort;
import zachkingcade.dev.user.domain.session.Session;
import zachkingcade.dev.user.domain.user.User;

import java.time.Instant;

@Service
public class UserService implements RegisterUserUseCase, LoginUserUseCase {

    UserRepositoryPort userRepository;
    private final PasswordEncoder passwordEncoder;
    CreateUserSessionUseCase createUserSessionUseCase;

    public UserService(UserRepositoryPort userRepository, PasswordEncoder passwordEncoder, CreateUserSessionUseCase createUserSessionUseCase) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.createUserSessionUseCase = createUserSessionUseCase;
    }

    @Override
    public User registerUser(RegisterUserCommand command) {
        // Check that this username does not already exist
        if(userRepository.existsByUsername(command.username())){
            throw new ApplicationException(String.format("Username [%s] is already taken", command.username()));
        }

        Instant currentTime = Instant.now();

        //create domain object
        User newUser = User.createNew(command.username(), command.password(), true, currentTime, currentTime);

        //encrypt password and save entity
        String hashedPassword = passwordEncoder.encode(command.password());
        UserEntity entity = new UserEntity();
        entity.setUsername(newUser.getUsername());
        entity.setPasswordHash(hashedPassword);
        entity.setActive(newUser.getActive());
        entity.setCreatedDate(newUser.getCreated_date());
        entity.setUpdatedDate(newUser.getUpdated_date());
        UserEntity saved = userRepository.save(entity);


        return newUser.withId(saved.getUserId());
    }

    @Override
    public Session loginUser(LoginUserCommand command) {
        // Find user
        UserEntity userEntity = userRepository.getByUsername(command.username()).orElseThrow( () ->
                new NotFoundException(String.format("User with the username [%s] not found", command.username()))
        );

        // Validate password
        boolean passwordMatches = passwordEncoder.matches(command.password(), userEntity.getPasswordHash());
        if(!passwordMatches){
            throw new ApplicationException("Password does not match data in our system.");
        }

        // Create Session
        CreateSessionCommand sessionCommand = new CreateSessionCommand(userEntity);
        Session session = this.createUserSessionUseCase.createSession(sessionCommand);
        return session;
    }
}
