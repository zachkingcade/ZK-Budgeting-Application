package zachkingcade.dev.user.adapter.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import zachkingcade.dev.user.adapter.web.dto.ApiResponse;
import zachkingcade.dev.user.adapter.web.dto.MetaData;
import zachkingcade.dev.user.adapter.web.dto.user.LoginUserRequest;
import zachkingcade.dev.user.adapter.web.dto.user.LoginUserResponse;
import zachkingcade.dev.user.adapter.web.dto.user.RegisterUserRequest;
import zachkingcade.dev.user.adapter.web.dto.user.RegisterUserResponse;
import zachkingcade.dev.user.application.commands.LoginUserCommand;
import zachkingcade.dev.user.application.commands.RegisterUserCommand;
import zachkingcade.dev.user.application.port.in.user.LoginUserUseCase;
import zachkingcade.dev.user.application.port.in.user.RegisterUserUseCase;
import zachkingcade.dev.user.domain.session.Session;
import zachkingcade.dev.user.domain.user.User;

@RestController()
@RequestMapping("/user")
public class UserController {

    RegisterUserUseCase registerUserUseCase;
    LoginUserUseCase loginUserUseCase;

    public UserController(RegisterUserUseCase registerUserUseCase, LoginUserUseCase loginUserUseCase) {
        this.registerUserUseCase = registerUserUseCase;
        this.loginUserUseCase = loginUserUseCase;
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<RegisterUserResponse>> registerUser(@RequestBody RegisterUserRequest request){
        RegisterUserCommand command = new RegisterUserCommand(request.username(), request.password());
        User newUser = registerUserUseCase.registerUser(command);
        RegisterUserResponse response = new RegisterUserResponse(newUser.getUsername());
        ApiResponse<RegisterUserResponse> apiResponse = new ApiResponse<>(String.format("Created User [%s]",newUser.getUsername()), new MetaData(1L), response);
        return new ResponseEntity<>(apiResponse, HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginUserResponse>> loginUser(@RequestBody LoginUserRequest request){
        LoginUserCommand command = new LoginUserCommand(request.username(), request.password());
        Session newSession = loginUserUseCase.loginUser(command);
        LoginUserResponse response = new LoginUserResponse(newSession.getUsername(), newSession.getSessionToken(), newSession.getCreated(), newSession.getExpires());
        ApiResponse<LoginUserResponse> apiResponse = new ApiResponse<>(String.format("User [%s] Logged into system successfully",request.username()), new MetaData(1L), response);
        return new ResponseEntity<>(apiResponse, HttpStatus.ACCEPTED);
    }
}
